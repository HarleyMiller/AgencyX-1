/*function TalkDogAnimation(){
var TalkDog_animation_time = new TimelineLite();
TweenMax.staggerTo(".TalkDog_animation_one", 1, {opacity:0}, 1),
TweenMax.staggerTo(".TalkDog_animation_one", 1, {opacity:50}, 1),
TweenMax.staggerTo(".TalkDog_animation_one", 1, {opacity:100}, 1);
}*/